package br.com.fiap.jpa.dao;

import br.com.fiap.entity.Paciente;

public interface PacienteDAO extends GenericDAO<Paciente, Integer> {

}
