package br.com.fiap.jpa.exception;

public class KeyNotFoundException extends Exception {

	public KeyNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public KeyNotFoundException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public KeyNotFoundException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public KeyNotFoundException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public KeyNotFoundException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	
	
}